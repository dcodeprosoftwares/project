# Deploying to Hostinger (VPS)

This guide assumes you have a **VPS plan** on Hostinger (e.g., KVM 1 or higher) running **Ubuntu 20.04/22.04**.

> **Note:** Shared hosting plans often do not support long-running Node.js processes or have limited support. A VPS is highly recommended for Next.js applications.

## 1. Server Setup
Access your VPS via SSH:
```bash
ssh root@your_vps_ip
```

### Install Node.js (v18 or v20)
```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs
```

### Install Process Manager (PM2)
PM2 keeps your app running in the background.
```bash
sudo npm install -g pm2
```

### Install Nginx (Reverse Proxy)
Nginx will forward traffic from port 80 (HTTP) to your app on port 3000.
```bash
sudo apt update
sudo apt install nginx -y
```

## 2. Prepare Application
Option A: **Git (Recommended)**
1. Push your code to GitHub.
2. Clone it on the server:
```bash
git clone https://github.com/your-username/your-repo.git
cd your-repo
```

Option B: **File Upload**
1. Zip your project (excluding `node_modules` and `.next`).
2. Upload to `/var/www/event-app` using SFTP (FileZilla) or `scp`.
3. Unzip on server.

## 3. Installation & Build
Inside your project directory on the server:

```bash
# Install dependencies
npm install

# Create environment file
nano .env
# Paste your .env content here (Make sure to set NEXTAUTH_URL=http://your_domain_or_ip)
# DATABASE_URL="file:./prod.db"

# Generate SQLite Client
npx prisma generate

# Push Database Schema
npx prisma db push

# Build the application
npm run build
```

## 4. Start Application
Start the app using PM2:
```bash
pm2 start "npm start" --name event-app
pm2 save
pm2 startup
```

## 5. Configure Nginx
Create a config file for your domain:
```bash
sudo nano /etc/nginx/sites-available/event-app
```

Paste the following:
```nginx
server {
    listen 80;
    server_name your_domain.com www.your_domain.com; # Or your IP

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

Enable the site:
```bash
sudo ln -s /etc/nginx/sites-available/event-app /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

## 6. Important Notes
- **Photos:** Uploaded photos are stored in `public/uploads`. Ensure this directory exists and permissions are set.
  ```bash
  mkdir -p public/uploads
  chmod 755 public/uploads
  ```
- **Database:** Since we are using SQLite (`dev.db`), backing up this file preserves your data. For production scaling, consider switching to PostgreSQL.
